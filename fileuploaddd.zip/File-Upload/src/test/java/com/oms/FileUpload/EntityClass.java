package com.oms.FileUpload;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "userInformation")
public class EntityClass {
	
	public EntityClass() {
		
	}
	
	public EntityClass(long userId, String userName, String password, long roleId, String emailId, String department,
			String designation) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.roleId = roleId;
		this.emailId = emailId;
		this.department = department;
		this.designation = designation;
	}

	@Id
	@Column(name = "userId")
	private long userId;

	@Column(name = "userName")
	private String userName;

	@Column(name = "password")
	private String password;

	@Column(name = "roleId")
	private long roleId;

	@Column(name = "emailId")
	private String emailId;

	@Column(name = "department")
	private String department;

	@Column(name = "designation")
	private String designation;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "EntityClass [userId=" + userId + ", userName=" + userName + ", password=" + password + ", roleId="
				+ roleId + ", emailId=" + emailId + ", department=" + department + ", designation=" + designation + "]";
	}
}
